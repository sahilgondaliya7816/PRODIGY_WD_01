
# Home Page:
![Screenshot (19)](https://github.com/bk408/PRODIGY_WD_01/assets/116827830/09587b7e-310d-4025-859a-48668fde5607)
# Shop:
![20240112_000816(869)](https://github.com/14-sahil/PRODIGY_WD_01/assets/126070964/9ad3ff1a-636e-49db-b37b-57b7e3e5fa47)
# Delivery:
![20240112_000828(454)](https://github.com/14-sahil/PRODIGY_WD_01/assets/126070964/d8083fdc-b40f-4379-8985-b61fc8bde46a)
# App:
![20240112_000837(166)](https://github.com/14-sahil/PRODIGY_WD_01/assets/126070964/8002faa7-6880-428b-b4df-2223b573d0ec)
# About & Contact:
![20240112_000844(620)](https://github.com/14-sahil/PRODIGY_WD_01/assets/126070964/1475d982-5307-43f3-8849-54d0a7d65fad)

# Key Features:
🔥 Responsive Design:Our landing page adapts seamlessly to various screen sizes, ensuring accessibility for all users, whether on desktop, tablet, or mobile.
<br> 
🔥 Stunning Visuals: We've incorporated eye-catching visuals that capture the essence of Starbucks' brand, creating an inviting and visually appealing atmosphere.<br> 
🔥 User-Friendly Navigation: The navigation menu is intuitive and user-friendly, allowing visitors to explore different sections of the page effortlessly.<br> 
🔥 Interactive Elements: Engage with our interactive elements that provide an immersive experience, such as hovering effects and clickable features.<br> 
🔥 Performance Optimized: We've optimized the page for speed, ensuring fast loading times and a smooth browsing experience for every user. Interactive Elements: Engage with our interactive elements that provide an immersive experience, such as hovering effects and clickable features.
